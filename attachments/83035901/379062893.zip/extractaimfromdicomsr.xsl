<?xml version="1.0" encoding="UTF-8"?>

<!-- Copyright (c) 2015-2018, David A. Clunie DBA Pixelmed Publishing. All rights reserved. -->

<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
version="1.0">

<xsl:output method="xml" indent="yes" omit-xml-declaration="no"/>

<xsl:template match="DicomStructuredReport">

	<xsl:variable name="imageLibraryNode" select="/DicomStructuredReport/DicomStructuredReportContent/container[concept/@csd = 'DCM' and concept/@cv = '126000']/container[concept/@csd = 'DCM' and concept/@cv = '111028']"/>	<!-- cm="Imaging Measurement Report" cm="Image Library" -->

	<ImageAnnotationCollection
		xmlns="gme://caCORE.caCORE/4.4/edu.northwestern.radiology.AIM"
		xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
		xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
		aimVersion="AIMv4_2"
		xsi:schemaLocation="gme://caCORE.caCORE/4.4/edu.northwestern.radiology.AIM AIM_v4.2_rv2_XML.xsd">



		<uniqueIdentifier  root="{normalize-space(DicomStructuredReportHeader/SOPInstanceUID/value)}"/>
		<studyInstanceUid  root="{normalize-space(DicomStructuredReportHeader/StudyInstanceUID/value)}"/>
		<seriesInstanceUid root="{normalize-space(DicomStructuredReportHeader/SeriesInstanceUID/value)}"/>
		<accessionNumber  value="{normalize-space(DicomStructuredReportHeader/AccessionNumber/value)}"/>
		
		<xsl:variable name="dateTimeRawValues">
			<xsl:value-of select="DicomStructuredReportHeader/ContentDate/value"/>
			<xsl:value-of select="DicomStructuredReportHeader/ContentTime/value"/>
		</xsl:variable>
		<dateTime value="{normalize-space($dateTimeRawValues)}"/>
		
		<user>
			<name                            value="{normalize-space(DicomStructuredReportContent/container[concept/@csd = 'DCM' and concept/@cv = '126000']/pname[concept/@csd = 'DCM' and concept/@cv = '121008']/value)}"/>	<!-- cm="Imaging Measurement Report" cm="Person Observer Name" -->
			<loginName                       value="{normalize-space(DicomStructuredReportContent/container[concept/@csd = 'DCM' and concept/@cv = '126000']/text[concept/@csd = 'DCM' and concept/@cv = '128774']/value)}"/>	<!-- cm="Imaging Measurement Report" cm="Person Observer's Login Name" -->
			<roleInTrial                     value="{normalize-space(DicomStructuredReportContent/container[concept/@csd = 'DCM' and concept/@cv = '126000']/code[concept/@csd = 'DCM' and concept/@cv = '121011']/value/@cm)}"/>	<!-- cm="Imaging Measurement Report" cm="Person Observer's Role in this Procedure" -->
			<numberWithinRoleOfClinicalTrial value="{normalize-space(DicomStructuredReportContent/container[concept/@csd = 'DCM' and concept/@cv = '126000']/code[concept/@csd = 'DCM' and concept/@cv = '121011']/text[concept/@csd = 'DCM' and concept/@cv = '128775']/value)}"/>	<!-- cm="Imaging Measurement Report" cm="Person Observer's Role in this Procedure" cm="Identifier within Person Observer's Role" -->
		</user>
		
		<equipment>
			<manufacturerName      value="{normalize-space(DicomStructuredReportHeader/Manufacturer/value)}"/>
			<manufacturerModelName value="{normalize-space(DicomStructuredReportHeader/ManufacturerModelName/value)}"/>
			<softwareVersion       value="{normalize-space(DicomStructuredReportHeader/SoftwareVersions/value)}"/>
		</equipment>
		
		<person>
			<name        value="{normalize-space(DicomStructuredReportHeader/PatientName/value)}"/>
			<id          value="{normalize-space(DicomStructuredReportHeader/PatientID/value)}"/>
			<birthDate   value="{normalize-space(DicomStructuredReportHeader/PatientBirthDate/value)}"/>
			<sex  	     value="{normalize-space(DicomStructuredReportHeader/PatientSex/value)}"/>
			<ethnicGroup value="{normalize-space(DicomStructuredReportHeader/EthnicGroup/value)}"/>
		</person>
		
		<imageAnnotations>
			
			<xsl:for-each select="DicomStructuredReportContent/container[concept/@csd = 'DCM' and concept/@cv = '126000']/container[concept/@csd = 'DCM' and concept/@cv = '126010']/container[concept/@csd = 'DCM' and concept/@cv = '125007']">	<!-- cm="Imaging Measurement Report" cm="Imaging Measurements" "Measurement Group" -->
				<ImageAnnotation>
					
					<!-- per CP 1779: uniqueIdentifier is not the same as trackingUniqueIdentifier - do not populate it :( -->
					
					<xsl:variable name="findingValueNode" select="code[concept/@csd = 'DCM' and concept/@cv = '121071']/value"/>	<!-- "Finding" -->
					
					<typeCode code="{normalize-space($findingValueNode/@cv)}" codeSystemName="{normalize-space($findingValueNode/@csd)}">
						<iso:displayName xmlns:iso="uri:iso.org:21090" value="{normalize-space($findingValueNode/@cm)}"/>
					</typeCode>
					
					<dateTime value=""/>	<!-- not populated in DICOM SR or mentioned in PS3.21 - ??? should use observation datetime ??? copy from top level ContentDate and Time :( -->
					
					<name                    value=  "{normalize-space(text[concept/@csd = 'DCM' and concept/@cv = '112039']/value)}"/>	<!-- "Tracking Identifier" -->
					<comment                 value=  "{normalize-space(text[concept/@csd = 'DCM' and concept/@cv = '121106']/value)}"/>	<!-- "Comment" -->
					<trackingUniqueIdentifier root="{normalize-space(uidref[concept/@csd = 'DCM' and concept/@cv = '112040']/value)}"/>	<!-- per CP 1779: "Tracking Unique Identifier" -->

					<calculationEntityCollection>
						<xsl:for-each select="num">
							<CalculationEntity>
								<typeCode code="{normalize-space(concept/@cv)}" codeSystemName="{normalize-space(concept/@csd)}">
									<iso:displayName xmlns:iso="uri:iso.org:21090" value="{normalize-space(concept/@cm)}"/>
								</typeCode>
								<xsl:for-each select="code[concept/@csd = 'DCM' and concept/@cv = '121401']/value">	<!-- "Derivation" -->
									<typeCode code="{normalize-space(@cv)}" codeSystemName="{normalize-space(@csd)}">
										<iso:displayName xmlns:iso="uri:iso.org:21090" value="{normalize-space(@cm)}"/>
									</typeCode>
								</xsl:for-each>
								<xsl:for-each select="code[concept/@csd = 'SRT' and concept/@cv = 'G-C036']/value">	<!-- "Measurement Method" -->
									<typeCode code="{normalize-space(@cv)}" codeSystemName="{normalize-space(@csd)}">
										<iso:displayName xmlns:iso="uri:iso.org:21090" value="{normalize-space(@cm)}"/>
									</typeCode>
								</xsl:for-each>
								<xsl:variable name="descriptionRawValues">
									<xsl:value-of select="concept/@cm"/>
									<xsl:text> </xsl:text>
									<xsl:value-of select="code[concept/@csd = 'DCM' and concept/@cv = '121401']/value/@cm"/>
									<xsl:text> </xsl:text>
									<xsl:value-of select="code[concept/@csd = 'SRT' and concept/@cv = 'G-C036']/value/@cm"/>
								</xsl:variable>
								<description value="{normalize-space($descriptionRawValues)}"/>

								<calculationResultCollection>
									<CalculationResult type="Scalar" xsi:type="CompactCalculationResult">
										<unitOfMeasure value="{normalize-space(units/@cv)}"/>
										<dataType code="C48870" codeSystemName="NCI">
											<iso:displayName xmlns:iso="uri:iso.org:21090" value="Double"/>
										</dataType>
										<dimensionCollection>
											<Dimension>
												<index value="0"/>
												<size value="1"/>
												<label value="{normalize-space(code[concept/@csd = 'DCM' and concept/@cv = '121401']/value/@cm)}"/>	<!-- "Derivation" -->
											</Dimension>
										</dimensionCollection>
										<value value="{value}"/>
									</CalculationResult>
								</calculationResultCollection>
								
								<algorithm>
									<name value="{normalize-space(text[concept/@csd = 'DCM' and concept/@cv = '111001']/value)}"/>	<!-- "Algorithm Name" -->
									<!-- nothing for <type/> -  nothing like this is stored in DICOM SR :( -->
									<version value="{normalize-space(text[concept/@csd = 'DCM' and concept/@cv = '111003']/value)}"/>	<!-- "Algorithm Version" -->
								</algorithm>

							</CalculationEntity>
						</xsl:for-each>
					</calculationEntityCollection>

					<segmentationEntityCollection>
						<xsl:for-each select="image[concept/@csd = 'DCM' and concept/@cv = '121191']">	<!-- "Referenced Segment" -->
							<SegmentationEntity>
								<!-- no uniqueIdentifier -->
								<xsl:variable name="segmentationSOPInstanceUID"><xsl:value-of select="normalize-space(instance)"/></xsl:variable>
								<sopInstanceUid root="{$segmentationSOPInstanceUID}"/>
								<studyInstanceUid  root="{normalize-space(/DicomStructuredReport/DicomStructuredReportHeader/CurrentRequestedProcedureEvidenceSequence/Item[normalize-space(ReferencedSeriesSequence/Item/ReferencedSOPSequence/Item/ReferencedSOPInstanceUID/value) = $segmentationSOPInstanceUID]/StudyInstanceUID/value)}"/>
								<seriesInstanceUid root="{normalize-space(/DicomStructuredReport/DicomStructuredReportHeader/CurrentRequestedProcedureEvidenceSequence/Item/ReferencedSeriesSequence/Item[normalize-space(ReferencedSOPSequence/Item/ReferencedSOPInstanceUID/value) = $segmentationSOPInstanceUID]/SeriesInstanceUID/value)}"/>
								<sopClassUid root="{normalize-space(class)}"/>
								<referencedSopInstanceUid root="{normalize-space(../image[concept/@csd = 'DCM' and concept/@cv = '121233']/instance)}"/>	<!-- "Source image for segmentation" -->
								<segmentNumber value="{normalize-space(segment)}"/>
							</SegmentationEntity>
						</xsl:for-each>
					</segmentationEntityCollection>
					
					
					<imageReferenceEntityCollection>
						<ImageReferenceEntity xsi:type="DicomImageReferenceEntity">
							<xsl:for-each select="/DicomStructuredReport/DicomStructuredReportHeader/CurrentRequestedProcedureEvidenceSequence/Item">
								<xsl:variable name="sopInstanceUIDOfFirstInstanceInStudy" select="normalize-space(ReferencedSeriesSequence/Item/ReferencedSOPSequence/Item/ReferencedSOPInstanceUID/value)"/>
								<!--<xsl:message>Have sopInstanceUIDOfFirstInstanceInStudy <xsl:value-of select="$sopInstanceUIDOfFirstInstanceInStudy"/></xsl:message>-->
								<xsl:variable name="imageLibraryNodeOfFirstInstanceInStudy" select="$imageLibraryNode/container[concept/@csd = 'DCM' and concept/@cv = '126200']/image[instance = $sopInstanceUIDOfFirstInstanceInStudy]"/>	<!-- Image Library Group" -->
								<!--<xsl:message>Have imageLibraryNodeOfFirstInstanceInStudy for instance <xsl:value-of select="$imageLibraryNodeOfFirstInstanceInStudy/instance"/></xsl:message>-->
								
								<xsl:if test="$imageLibraryNodeOfFirstInstanceInStudy">		<!-- if not in Image Library then may be segmentation, which we don't want to include in imageReferenceEntityCollection -->
									<imageStudy>
										<instanceUid root="{normalize-space(StudyInstanceUID/value)}"/>
										<accessionNumber value="{normalize-space($imageLibraryNodeOfFirstInstanceInStudy/text[concept/@csd = 'DCM' and concept/@cv = '121022'])}"/>	<!-- "Accession Number" -->
										<startDate       value="{normalize-space($imageLibraryNodeOfFirstInstanceInStudy/date[concept/@csd = 'DCM' and concept/@cv = '111060'])}"/>	<!-- "Study Date" -->
										<startTime       value="{normalize-space($imageLibraryNodeOfFirstInstanceInStudy/time[concept/@csd = 'DCM' and concept/@cv = '111061'])}"/>	<!-- "Study Time" -->
										<xsl:for-each select="ReferencedSeriesSequence/Item">
											<xsl:variable name="sopInstanceUIDOfFirstInstanceInSeries" select="normalize-space(ReferencedSOPSequence/Item/ReferencedSOPInstanceUID/value)"/>
											<!--<xsl:message>Have sopInstanceUIDOfFirstInstanceInSeries <xsl:value-of select="$sopInstanceUIDOfFirstInstanceInSeries"/></xsl:message>-->
											<xsl:variable name="imageLibraryNodeOfFirstInstanceInSeries" select="$imageLibraryNode/container[concept/@csd = 'DCM' and concept/@cv = '126200']/image[instance = $sopInstanceUIDOfFirstInstanceInSeries]"/>	<!-- Image Library Group" -->
											<!--<xsl:message>Have imageLibraryNodeOfFirstInstanceInSeries for instance <xsl:value-of select="$imageLibraryNodeOfFirstInstanceInSeries/instance"/></xsl:message>-->
											
											<imageSeries>
												<instanceUid root="{normalize-space(SeriesInstanceUID/value)}"/>
												<xsl:variable name="modalityValueNode" select="$imageLibraryNodeOfFirstInstanceInSeries/code[concept/@csd = 'DCM' and concept/@cv = '121139']/value"/>	<!-- "Modality" -->
												<modality code="{normalize-space($modalityValueNode/@cv)}" codeSystemName="{normalize-space($modalityValueNode/@csd)}">
													<iso:displayName xmlns:iso="uri:iso.org:21090" value="{normalize-space($modalityValueNode/@cm)}"/>
												</modality>
												<imageCollection>
													<xsl:for-each select="ReferencedSOPSequence/Item">
														<Image>
															<sopClassUid root="{normalize-space(ReferencedSOPClassUID/value)}"/>
															<sopInstanceUid root="{normalize-space(ReferencedSOPInstanceUID/value)}"/>
														</Image>
													</xsl:for-each>
												</imageCollection>
											</imageSeries>
										</xsl:for-each>
									</imageStudy>
								</xsl:if>
							</xsl:for-each>
						</ImageReferenceEntity>
					</imageReferenceEntityCollection>

				</ImageAnnotation>
			</xsl:for-each>
			
			
			
		</imageAnnotations>
		
	</ImageAnnotationCollection>

</xsl:template>

</xsl:stylesheet>
